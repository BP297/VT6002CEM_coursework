//
//  MyView.swift
//  PORApp
//
//  Created by ituser on 1/31/24.
//

import SwiftUI

struct MyView: View {
    var body: some View {
        NavigationStack{
            VStack {
                Text("The POR for VT6002CEM")
            }
            .navigationTitle("Profile")
        }
        
    }
}

struct MyView_Preview : PreviewProvider {
    static var previews: some View {
        MyView()
    }
}
