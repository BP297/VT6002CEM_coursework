//
//  MainView.swift
//  PORApp
//
//  Created by ituser on 1/31/24.
//

import SwiftUI

struct MainView: View {
    var parkData = ParkData()
    var weatherViewModel = WeatherViewModel()
    @State var parks :  [Park] = []
    @State var weatherData : WeatherData?
    
    init() {
        let appearance = UINavigationBarAppearance()
        appearance.backgroundColor = .green
        UINavigationBar.appearance().standardAppearance = appearance
        UINavigationBar.appearance().scrollEdgeAppearance = appearance
    }
    
    var body: some View {
        TabView {
            NearestView(parks: $parks)
                .tabItem { Label("Nearby", systemImage: "location") }
            ParksView(parks: $parks)
                .tabItem { Label("Parks", systemImage: "figure.walk") }
            WeatherView(weatherData: weatherData)
                .tabItem { Label("Weather", systemImage: "cloud.sun.fill") }
            RecordsView()
                .tabItem { Label("Note", systemImage: "mappin") }
            MyView()
                .tabItem { Label("Account", systemImage: "person.fill") }
        }
        .onAppear() {
            parkData.fetch({
                parks in
                print("draw park informations")
                self.parks = parks
            })
            
            weatherViewModel.fetchWeatherData(completion: {
                weather in
                self.weatherData = weather
            })
        }
    }
}

struct MainView_Preview : PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
