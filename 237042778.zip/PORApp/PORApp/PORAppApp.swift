//
//  PORAppApp.swift
//  PORApp
//
//  Created by ituser on 1/31/24.
//

import SwiftUI

@main
struct PORAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
